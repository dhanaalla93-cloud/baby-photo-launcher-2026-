package com.babylauncher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(com.babylauncher.R.drawable.baby_wallpaper)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1,-1))
        val shade = View(this); shade.setBackgroundColor(0x33000000)
        root.addView(shade, FrameLayout.LayoutParams(-1,-1))
        content = LinearLayout(this); content.orientation = LinearLayout.VERTICAL
        content.setPadding(22,36,22,18)
        root.addView(content, FrameLayout.LayoutParams(-1,-1))
        val clock = TextView(this)
        clock.text = java.text.SimpleDateFormat("h:mm", java.util.Locale.getDefault()).format(java.util.Date())
        clock.textSize = 46f; clock.setTextColor(Color.WHITE); clock.typeface = Typeface.create("sans-serif-light",0)
        clock.gravity = Gravity.CENTER
        content.addView(clock, LinearLayout.LayoutParams(-1,0,1f))
        val date = TextView(this)
        date.text = java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault()).format(java.util.Date())
        date.textSize=16f; date.setTextColor(Color.WHITE); date.gravity=Gravity.CENTER
        content.addView(date)
        val spacer=Space(this); content.addView(spacer,LinearLayout.LayoutParams(1,0,1f))
        val row=LinearLayout(this); row.gravity=Gravity.CENTER; row.orientation=LinearLayout.HORIZONTAL
        content.addView(row)
        addShortcut(row,"☎","Phone","com.google.android.dialer")
        addShortcut(row,"✉","Messages","com.google.android.apps.messaging")
        addShortcut(row,"◎","Camera","")
        addShortcut(row,"▣","Gallery","")
        val apps=Button(this); apps.text="All Apps  ⌃"; apps.setTextColor(Color.WHITE)
        apps.setBackgroundColor(0x66301A0A.toInt()); apps.setOnClickListener { showApps() }
        content.addView(apps,LinearLayout.LayoutParams(-1,54))
        setContentView(root)
    }
    private fun addShortcut(row: LinearLayout, glyph:String, label:String, pkg:String) {
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.gravity=Gravity.CENTER
        val b=TextView(this); b.text=glyph; b.textSize=26f; b.gravity=Gravity.CENTER
        b.setTextColor(Color.WHITE); b.background=android.graphics.drawable.GradientDrawable().apply {
            shape=android.graphics.drawable.GradientDrawable.OVAL; setColor(0xAA6D3D20.toInt())
        }
        val lp=LinearLayout.LayoutParams(58,58); lp.setMargins(8,4,8,4); box.addView(b,lp)
        val t=TextView(this); t.text=label; t.textSize=11f; t.setTextColor(Color.WHITE); t.gravity=Gravity.CENTER
        box.addView(t)
        box.setOnClickListener {
            try {
                if(pkg.isNotEmpty()) startActivity(packageManager.getLaunchIntentForPackage(pkg))
                else if(label=="Camera") startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                else showApps()
            } catch (_:Exception) { showApps() }
        }
        row.addView(box)
    }
    private fun showApps() {
        val list=packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0)
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val scroll=ScrollView(this)
        val column=LinearLayout(this); column.orientation=LinearLayout.VERTICAL
        column.setPadding(20,24,20,24)
        val title=TextView(this); title.text="Baby Launcher • Apps"; title.textSize=22f; title.setTextColor(Color.WHITE)
        column.addView(title)
        list.forEach { info ->
            val item=TextView(this); item.text="  "+info.loadLabel(packageManager); item.textSize=18f
            item.setTextColor(Color.WHITE); item.setPadding(12,14,12,14)
            item.setCompoundDrawablesWithIntrinsicBounds(info.loadIcon(packageManager),null,null,null)
            item.setOnClickListener { startActivity(packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)) }
            column.addView(item)
        }
        val back=Button(this); back.text="Back to Home"; back.setOnClickListener { setContentView(root) }; column.addView(back)
        scroll.addView(column); scroll.setBackgroundColor(0xEE4A210C.toInt()); setContentView(scroll)
    }
}
